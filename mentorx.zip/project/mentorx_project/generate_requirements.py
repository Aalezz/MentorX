import os
import sys

# List of required packages
required_packages = [
    "flask",
    "python-docx",
    "PyPDF2",
    "nltk",
    "requests"
]

# Generate requirements.txt
with open('/home/ubuntu/mentorx_project/requirements.txt', 'w') as f:
    for package in required_packages:
        f.write(f"{package}\n")

print("Requirements file generated successfully.")
