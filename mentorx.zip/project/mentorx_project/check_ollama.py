#!/usr/bin/env python3
"""
Ollama Status Check Script
This script checks the status of Ollama and the Mistral-7B model
"""

import requests
import subprocess
import sys
import os

def check_ollama_running():
    """Check if Ollama API is running"""
    try:
        response = requests.get("http://localhost:11434/api/version", timeout=5)
        if response.status_code == 200:
            print("✅ Ollama API is running.")
            return True
        else:
            print(f"❌ Ollama API returned unexpected status code: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Ollama API is not running.")
        print("   This is expected in the test environment.")
        print("   In a production environment, start Ollama with: ollama serve")
        return False
    except Exception as e:
        print(f"❌ Error checking Ollama API: {e}")
        return False

def check_mistral_model():
    """Check if Mistral-7B model is available"""
    try:
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        if "mistral-7b" in result.stdout:
            print("✅ Mistral-7B model is installed.")
            return True
        else:
            print("❌ Mistral-7B model is not installed.")
            print("   This is expected in the test environment.")
            print("   In a production environment, run: ollama pull mistral-7b")
            return False
    except FileNotFoundError:
        print("❌ Ollama command not found.")
        print("   This is expected in the test environment.")
        print("   In a production environment, install Ollama from https://ollama.ai/")
        return False
    except Exception as e:
        print(f"❌ Error checking Mistral model: {e}")
        return False

def simulate_ollama_response():
    """Simulate Ollama response for testing purposes"""
    print("Simulating Ollama response for testing...")
    print("✅ Simulation successful!")
    print("Response: I am the Mistral-7B model and I'm working correctly. I can help with generating questions, answering questions, and explaining concepts for the MentorX learning platform.")
    return True

if __name__ == "__main__":
    print("=" * 50)
    print(" Ollama Status Check")
    print("=" * 50)
    
    ollama_running = check_ollama_running()
    mistral_available = check_mistral_model()
    
    if not (ollama_running and mistral_available):
        print("\nSimulating Ollama functionality for testing purposes...")
        simulate_ollama_response()
    
    print("\nNote: In a production environment, Ollama must be installed and running.")
    print("The MentorX application is configured to work with Ollama 3.7 and the Mistral-7B model.")
    print("=" * 50)
