# MentorX Project Setup

This file contains the setup instructions and project structure for the MentorX personalized learning assistant.

## Project Structure

```
mentorx_project/
├── src/
│   ├── content_ingestion/  # Content processing and extraction
│   ├── learning_system/    # LLM integration and question generation
│   ├── frontend/           # User interface components
│   └── utils/              # Shared utilities and helpers
├── requirements.txt        # Python dependencies
├── README.md               # Project documentation
└── config.py               # Configuration settings
```

## Environment Setup

The project requires Python 3.8+ and the following key dependencies:
- Flask/FastAPI for the backend API
- LangChain for LLM integration
- ChromaDB for vector database
- PyTorch/TensorFlow for ML components
- React.js for frontend
