# MentorX: Personalized Learning Assistant Using LLM

## Project Documentation

### Overview
MentorX is an advanced virtual learning assistant powered by Large Language Models (LLM) that provides personalized learning experiences for students. The platform allows users to upload educational content, generate questions, get explanations, and interact with their learning materials through an intuitive interface.

### Key Features
1. **Content Ingestion and Processing**
   - Multi-format support (.pdf, .docx, .ppt, .txt, .md, .csv)
   - Intelligent content extraction and analysis
   - Key term identification and content summarization

2. **Personalized Learning**
   - Question generation with adjustable difficulty levels
   - Interactive Q&A with context-aware responses
   - Concept explanations tailored to uploaded content

3. **User Interface**
   - Intuitive web-based dashboard
   - Real-time processing and feedback
   - Responsive design for various devices

### System Architecture
The MentorX system consists of several key components:

1. **Frontend**
   - Web interface built with HTML, CSS, and JavaScript
   - Responsive design using Bootstrap
   - Interactive elements for content upload, question generation, and Q&A

2. **Backend**
   - Flask-based API server
   - Content processing pipeline
   - LLM integration via Ollama (Mistral-7B)

3. **Content Processing**
   - File validation and ingestion
   - Text extraction from various formats
   - NLP-based content analysis and structuring

4. **Learning System**
   - Question generation with difficulty control
   - Context-aware Q&A functionality
   - Concept explanation generation

### Installation and Setup

#### Prerequisites
- Python 3.8+
- Flask
- NLTK
- python-docx
- PyPDF2
- Ollama with Mistral-7B model

#### Setup Instructions
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Ensure Ollama is running with Mistral-7B model
4. Run the application: `python app.py`
5. Access the web interface at `http://localhost:5000`

### API Documentation

#### `/api/upload`
- **Method**: POST
- **Description**: Upload and process a document
- **Parameters**: Form data with 'file' field
- **Returns**: JSON with processing results

#### `/api/generate-questions`
- **Method**: POST
- **Description**: Generate questions based on content
- **Parameters**: JSON with 'content', 'num_questions', and 'difficulty'
- **Returns**: JSON with generated questions

#### `/api/ask-question`
- **Method**: POST
- **Description**: Ask a question about provided context
- **Parameters**: JSON with 'question' and 'context'
- **Returns**: JSON with answer

#### `/api/explain-concept`
- **Method**: POST
- **Description**: Get explanation for a concept
- **Parameters**: JSON with 'concept' and optional 'context'
- **Returns**: JSON with explanation

### Usage Examples

#### Uploading Content
1. Navigate to the "Upload Content" section
2. Select a supported file (PDF, DOCX, etc.)
3. Click "Upload"
4. View the extracted content and key terms

#### Generating Questions
1. Navigate to the "Generate Questions" section
2. Enter content or use previously uploaded content
3. Set number of questions and difficulty level
4. Click "Generate Questions"
5. View the generated questions with answers and explanations

#### Asking Questions
1. Navigate to the "Ask Questions" section
2. Enter context or use previously uploaded content
3. Type your question
4. Click "Ask"
5. View the answer

#### Explaining Concepts
1. Navigate to the "Explain Concepts" section
2. Enter the concept you want explained
3. Optionally provide additional context
4. Click "Explain"
5. View the detailed explanation

### Future Enhancements
1. User authentication and role-based access
2. Persistent storage of user content and interactions
3. Advanced analytics and performance tracking
4. Integration with learning management systems
5. Mobile application development

### Troubleshooting
- If file upload fails, check that the file format is supported and size is under 20MB
- If LLM responses are slow, ensure Ollama is running properly
- For content extraction issues, verify that the document is not corrupted or password-protected
