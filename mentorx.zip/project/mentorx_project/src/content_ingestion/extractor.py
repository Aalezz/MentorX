import os
from typing import Dict, Any, List, Optional
import mimetypes

from ..config import Config

class ContentExtractor:
    """
    Extracts content from various file formats for processing by the MentorX system.
    """
    
    @staticmethod
    def extract_content(file_path: str) -> Dict[str, Any]:
        """
        Extracts text content from a file based on its format.
        
        Args:
            file_path: Path to the file to extract content from
            
        Returns:
            Dict containing extraction results
        """
        result = {
            "success": False,
            "message": "",
            "content": "",
            "metadata": {}
        }
        
        # Check if file exists
        if not os.path.exists(file_path):
            result["message"] = "File does not exist"
            return result
        
        # Get file extension
        file_ext = os.path.splitext(file_path)[1].lower()
        
        try:
            # Extract content based on file type
            if file_ext in ['.txt', '.md', '.csv']:
                with open(file_path, 'r', encoding='utf-8') as f:
                    result["content"] = f.read()
                    result["success"] = True
                    
            elif file_ext in ['.docx', '.doc']:
                try:
                    import docx
                    doc = docx.Document(file_path)
                    
                    # Extract text from paragraphs
                    paragraphs = [para.text for para in doc.paragraphs]
                    
                    # Extract text from tables
                    for table in doc.tables:
                        for row in table.rows:
                            for cell in row.cells:
                                for paragraph in cell.paragraphs:
                                    paragraphs.append(paragraph.text)
                    
                    # Join all text
                    result["content"] = "\n".join(paragraphs)
                    
                    # Extract metadata
                    result["metadata"] = {
                        "title": doc.core_properties.title if doc.core_properties.title else "",
                        "author": doc.core_properties.author if doc.core_properties.author else "",
                        "created": str(doc.core_properties.created) if doc.core_properties.created else "",
                        "modified": str(doc.core_properties.modified) if doc.core_properties.modified else ""
                    }
                    
                    result["success"] = True
                    result["message"] = "Content extracted successfully from DOCX"
                except ImportError:
                    result["message"] = "python-docx module not installed. Using simple text extraction."
                    # Fallback to simple text extraction
                    with open(file_path, 'rb') as f:
                        result["content"] = f"[Document content from {os.path.basename(file_path)}]"
                        result["success"] = True
                
            elif file_ext in ['.pdf']:
                try:
                    import PyPDF2
                    with open(file_path, 'rb') as file:
                        pdf_reader = PyPDF2.PdfReader(file)
                        
                        # Extract text from pages
                        text = []
                        for page_num in range(len(pdf_reader.pages)):
                            page = pdf_reader.pages[page_num]
                            text.append(page.extract_text())
                        
                        # Join all text
                        result["content"] = "\n".join(text)
                        
                        # Extract metadata if available
                        if pdf_reader.metadata:
                            result["metadata"] = {
                                "title": pdf_reader.metadata.get('/Title', ''),
                                "author": pdf_reader.metadata.get('/Author', ''),
                                "creator": pdf_reader.metadata.get('/Creator', ''),
                                "producer": pdf_reader.metadata.get('/Producer', '')
                            }
                        
                        result["success"] = True
                        result["message"] = "Content extracted successfully from PDF"
                except ImportError:
                    result["message"] = "PyPDF2 module not installed. Using simple text extraction."
                    # Fallback to simple text extraction
                    result["content"] = f"[PDF content from {os.path.basename(file_path)}]"
                    result["success"] = True
                
            elif file_ext in ['.pptx', '.ppt']:
                # Placeholder for PowerPoint extraction
                result["content"] = f"[PowerPoint content from {os.path.basename(file_path)}]"
                result["success"] = True
                result["message"] = "PowerPoint extraction using placeholder"
            
            else:
                result["message"] = f"Unsupported file format: {file_ext}"
                return result
                
        except Exception as e:
            result["message"] = f"Error extracting content: {str(e)}"
            return result
        
        # Set success if not already set
        if "success" not in result or not result["success"]:
            result["success"] = True
            result["message"] = "Content extracted successfully"
            
        return result

# Add a top-level function for direct import in app.py
def extract_content(file_path: str, file_type: str = None) -> Dict[str, Any]:
    """
    Wrapper function to extract content from files.
    
    Args:
        file_path: Path to the file to extract content from
        file_type: Optional file type hint
        
    Returns:
        Dict containing extraction results
    """
    return ContentExtractor.extract_content(file_path)
