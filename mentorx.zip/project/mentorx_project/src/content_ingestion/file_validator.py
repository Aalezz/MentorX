import os
from pathlib import Path
from typing import List, Dict, Any, Optional
import mimetypes

from ..config import Config

class FileValidator:
    """
    Validates uploaded files for compatibility with the MentorX system.
    """
    
    @staticmethod
    def validate_file(file_path: str) -> Dict[str, Any]:
        """
        Validates if a file is compatible with the system.
        
        Args:
            file_path: Path to the file to validate
            
        Returns:
            Dict containing validation results
        """
        result = {
            "valid": False,
            "message": "",
            "file_type": None,
            "file_size": 0
        }
        
        # Check if file exists
        if not os.path.exists(file_path):
            result["message"] = "File does not exist"
            return result
        
        # Get file extension and check if supported
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext not in Config.SUPPORTED_FORMATS:
            result["message"] = f"Unsupported file format: {file_ext}"
            return result
        
        # Check file size
        file_size = os.path.getsize(file_path)
        result["file_size"] = file_size
        if file_size > Config.MAX_FILE_SIZE:
            result["message"] = f"File too large: {file_size} bytes (max {Config.MAX_FILE_SIZE} bytes)"
            return result
        
        # Determine file type
        result["file_type"] = mimetypes.guess_type(file_path)[0]
        
        # All checks passed
        result["valid"] = True
        result["message"] = "File is valid"
        return result
    
    @staticmethod
    def get_supported_formats() -> List[str]:
        """
        Returns a list of supported file formats.
        
        Returns:
            List of supported file extensions
        """
        return Config.SUPPORTED_FORMATS

# Add a top-level function for direct import in app.py
def validate_file(file):
    """
    Wrapper function to validate uploaded file objects.
    
    Args:
        file: Flask file object from request.files
        
    Returns:
        Dict containing validation results
    """
    # For Flask file objects, we need to check differently
    result = {
        "valid": False,
        "message": "",
        "file_type": None,
        "file_size": 0
    }
    
    # Check if file has a name
    if file.filename == '':
        result["message"] = "No selected file"
        return result
    
    # Get file extension and check if supported
    file_ext = os.path.splitext(file.filename)[1].lower()
    if file_ext not in Config.SUPPORTED_FORMATS:
        result["message"] = f"Unsupported file format: {file_ext}"
        return result
    
    # Check file size (read content length from request)
    file.seek(0, os.SEEK_END)
    file_size = file.tell()
    file.seek(0)  # Reset file pointer
    
    result["file_size"] = file_size
    if file_size > Config.MAX_FILE_SIZE:
        result["message"] = f"File too large: {file_size} bytes (max {Config.MAX_FILE_SIZE} bytes)"
        return result
    
    # Determine file type
    result["file_type"] = mimetypes.guess_type(file.filename)[0]
    
    # All checks passed
    result["valid"] = True
    result["message"] = "File is valid"
    return result
