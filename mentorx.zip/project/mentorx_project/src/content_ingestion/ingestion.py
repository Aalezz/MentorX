import os
from typing import Dict, Any, List, Optional
import shutil
from pathlib import Path

from ..config import Config
from .file_validator import FileValidator

class ContentIngestion:
    """
    Handles the ingestion of content files into the MentorX system.
    """
    
    def __init__(self):
        """Initialize the content ingestion system."""
        # Ensure upload directory exists
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    
    def ingest_file(self, file_path: str, destination_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Ingests a file into the system, validating and copying it to the upload folder.
        
        Args:
            file_path: Path to the file to ingest
            destination_name: Optional name for the destination file
            
        Returns:
            Dict containing ingestion results
        """
        result = {
            "success": False,
            "message": "",
            "file_path": None,
            "validation": None,
            "file_type": None
        }
        
        # Validate the file
        validation = FileValidator.validate_file(file_path)
        result["validation"] = validation
        
        if not validation["valid"]:
            result["message"] = f"File validation failed: {validation['message']}"
            return result
        
        # Determine destination path
        if destination_name:
            dest_filename = destination_name
        else:
            dest_filename = os.path.basename(file_path)
        
        # Ensure unique filename
        dest_path = os.path.join(Config.UPLOAD_FOLDER, dest_filename)
        if os.path.exists(dest_path):
            base, ext = os.path.splitext(dest_filename)
            dest_filename = f"{base}_{os.urandom(4).hex()}{ext}"
            dest_path = os.path.join(Config.UPLOAD_FOLDER, dest_filename)
        
        # Copy file to upload folder
        try:
            shutil.copy2(file_path, dest_path)
            result["success"] = True
            result["message"] = "File ingested successfully"
            result["file_path"] = dest_path
            result["file_type"] = validation["file_type"]
        except Exception as e:
            result["message"] = f"Error copying file: {str(e)}"
        
        return result
    
    def list_ingested_files(self) -> List[Dict[str, Any]]:
        """
        Lists all files that have been ingested into the system.
        
        Returns:
            List of dicts containing file information
        """
        files = []
        
        for filename in os.listdir(Config.UPLOAD_FOLDER):
            file_path = os.path.join(Config.UPLOAD_FOLDER, filename)
            if os.path.isfile(file_path):
                file_info = {
                    "filename": filename,
                    "path": file_path,
                    "size": os.path.getsize(file_path),
                    "type": os.path.splitext(filename)[1].lower()
                }
                files.append(file_info)
        
        return files

# Add a top-level function for direct import in app.py
def ingest_content(file_path: str) -> Dict[str, Any]:
    """
    Wrapper function to ingest content files.
    
    Args:
        file_path: Path to the file to ingest
        
    Returns:
        Dict containing ingestion results
    """
    ingestion = ContentIngestion()
    return ingestion.ingest_file(file_path)
