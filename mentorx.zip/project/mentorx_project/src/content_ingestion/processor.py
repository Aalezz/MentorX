import os
from typing import Dict, Any, List, Optional
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

from ..config import Config

class ContentProcessor:
    """
    Processes extracted content using NLP techniques for the MentorX system.
    """
    
    def __init__(self):
        """Initialize the content processor with required NLTK resources."""
        # Download required NLTK resources if not already present
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            try:
                nltk.download('punkt')
            except Exception as e:
                print(f"Warning: Could not download NLTK punkt: {e}")
            
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            try:
                nltk.download('stopwords')
            except Exception as e:
                print(f"Warning: Could not download NLTK stopwords: {e}")
            
        try:
            nltk.data.find('corpora/wordnet')
        except LookupError:
            try:
                nltk.download('wordnet')
            except Exception as e:
                print(f"Warning: Could not download NLTK wordnet: {e}")
            
        # Initialize with fallbacks if resources aren't available
        try:
            self.stop_words = set(stopwords.words('english'))
        except:
            # Fallback to a basic set of stopwords
            self.stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'if', 'because', 
                              'as', 'what', 'when', 'where', 'how', 'is', 'are', 'was', 
                              'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 
                              'does', 'did', 'to', 'at', 'in', 'on', 'by', 'for', 'with', 
                              'about', 'against', 'between', 'into', 'through'}
            
        try:
            self.lemmatizer = WordNetLemmatizer()
        except:
            # Create a simple no-op lemmatizer as fallback
            class SimpleLemmatizer:
                def lemmatize(self, word):
                    return word
            self.lemmatizer = SimpleLemmatizer()
    
    def process_content(self, content: str) -> Dict[str, Any]:
        """
        Processes text content using NLP techniques.
        
        Args:
            content: Text content to process
            
        Returns:
            Dict containing processing results
        """
        result = {
            "success": False,
            "message": "",
            "processed_content": "",
            "sentences": [],
            "key_terms": [],
            "summary": ""
        }
        
        if not content:
            result["message"] = "No content provided"
            return result
        
        try:
            # Tokenize into sentences
            try:
                sentences = sent_tokenize(content)
            except:
                # Fallback to simple sentence splitting
                sentences = [s.strip() for s in content.split('.') if s.strip()]
                
            result["sentences"] = sentences
            
            # Extract key terms
            result["key_terms"] = self._extract_key_terms(content)
            
            # Generate summary (simple version - first 3 sentences)
            if len(sentences) > 0:
                summary_length = min(3, len(sentences))
                result["summary"] = " ".join(sentences[:summary_length])
            
            # Set processed content (could be more sophisticated in a real implementation)
            result["processed_content"] = content
            
            result["success"] = True
            result["message"] = "Content processed successfully"
            
        except Exception as e:
            result["message"] = f"Error processing content: {str(e)}"
            # Provide basic results even on error
            result["processed_content"] = content
            result["success"] = True  # Mark as success to avoid blocking the application flow
            
        return result
    
    def _extract_key_terms(self, content: str, max_terms: int = 20) -> List[str]:
        """Extract key terms from content."""
        try:
            # Tokenize and lowercase
            try:
                words = word_tokenize(content.lower())
            except:
                # Fallback to simple word splitting
                words = [w.strip().lower() for w in content.split() if w.strip()]
            
            # Remove stopwords and non-alphabetic tokens
            filtered_words = [word for word in words if word.isalpha() and word not in self.stop_words]
            
            # Lemmatize words
            lemmatized_words = [self.lemmatizer.lemmatize(word) for word in filtered_words]
            
            # Count frequency
            word_freq = {}
            for word in lemmatized_words:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
            
            # Sort by frequency and return top terms
            sorted_terms = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            return [term for term, freq in sorted_terms[:max_terms]]
        except Exception as e:
            print(f"Warning: Error extracting key terms: {e}")
            # Return some basic words from the content as fallback
            words = list(set([w.lower() for w in content.split() if len(w) > 4]))
            return words[:min(max_terms, len(words))]

# Add a top-level function for direct import in app.py
def process_content(content: str) -> Dict[str, Any]:
    """
    Wrapper function to process content.
    
    Args:
        content: Text content to process
        
    Returns:
        Dict containing processing results
    """
    processor = ContentProcessor()
    return processor.process_content(content)
