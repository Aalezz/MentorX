import os
import sys
from pathlib import Path

# Configuration settings for MentorX project
class Config:
    # Base paths
    BASE_DIR = Path(__file__).parent.absolute()
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    
    # LLM settings
    LLM_MODEL = "mistral-7b"
    LLM_API_URL = "http://localhost:11434/api"  # Default Ollama API endpoint
    
    # Database settings
    VECTOR_DB_PATH = os.path.join(BASE_DIR, "vector_db")
    
    # Content processing settings
    MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB
    SUPPORTED_FORMATS = [
        ".pdf", ".docx", ".doc", ".pptx", ".ppt", 
        ".txt", ".md", ".csv"
    ]
    
    # Performance settings
    PROCESSING_TIMEOUT = 30  # seconds
    
    # Create necessary directories
    @classmethod
    def setup(cls):
        os.makedirs(cls.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs(cls.VECTOR_DB_PATH, exist_ok=True)
        
        return True
