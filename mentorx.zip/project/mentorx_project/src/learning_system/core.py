from typing import Dict, Any, List, Optional
import os
from pathlib import Path

from ..config import Config
from ..content_ingestion.ingestion import ContentIngestion
from ..content_ingestion.extractor import ContentExtractor
from ..content_ingestion.processor import ContentProcessor
from .llm_interface import LLMInterface

class MentorXCore:
    """
    Core class that integrates all components of the MentorX system.
    """
    
    def __init__(self):
        """Initialize the MentorX core system."""
        # Create necessary directories
        Config.setup()
        
        # Initialize components
        self.content_ingestion = ContentIngestion()
        self.content_processor = ContentProcessor()
        self.llm_interface = LLMInterface()
    
    def process_document(self, file_path: str) -> Dict[str, Any]:
        """
        Process a document through the entire pipeline.
        
        Args:
            file_path: Path to the document to process
            
        Returns:
            Dict containing processing results
        """
        result = {
            "success": False,
            "message": "",
            "stages": {}
        }
        
        # Stage 1: Ingest the file
        ingest_result = self.content_ingestion.ingest_file(file_path)
        result["stages"]["ingestion"] = ingest_result
        
        if not ingest_result["success"]:
            result["message"] = f"Ingestion failed: {ingest_result['message']}"
            return result
        
        # Stage 2: Extract content
        extract_result = ContentExtractor.extract_content(ingest_result["file_path"])
        result["stages"]["extraction"] = extract_result
        
        if not extract_result["success"]:
            result["message"] = f"Extraction failed: {extract_result['message']}"
            return result
        
        # Stage 3: Process content
        process_result = self.content_processor.process_content(extract_result["content"])
        result["stages"]["processing"] = process_result
        
        if not process_result["success"]:
            result["message"] = f"Processing failed: {process_result['message']}"
            return result
        
        # Set overall success
        result["success"] = True
        result["message"] = "Document processed successfully through all stages"
        
        return result
    
    def generate_questions(self, content: str, num_questions: int = 5, 
                          difficulty: str = "medium") -> Dict[str, Any]:
        """
        Generate questions based on content.
        
        Args:
            content: Content to generate questions from
            num_questions: Number of questions to generate
            difficulty: Difficulty level (easy, medium, hard)
            
        Returns:
            Dict containing generated questions
        """
        return self.llm_interface.generate_questions(content, num_questions, difficulty)
    
    def ask_question(self, question: str, context: str) -> Dict[str, Any]:
        """
        Ask a question about the provided context.
        
        Args:
            question: Question to ask
            context: Context for the question
            
        Returns:
            Dict containing the answer
        """
        return self.llm_interface.generate_response(question, context)
    
    def explain_concept(self, concept: str, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate an explanation for a concept.
        
        Args:
            concept: Concept to explain
            context: Optional context
            
        Returns:
            Dict containing the explanation
        """
        return self.llm_interface.explain_concept(concept, context)

# Add top-level functions for direct import in app.py
_core_instance = None

def _get_core_instance():
    """Get or create a singleton instance of MentorXCore"""
    global _core_instance
    if _core_instance is None:
        try:
            _core_instance = MentorXCore()
        except Exception as e:
            print(f"Warning: Error initializing MentorXCore: {e}")
            # Create a minimal core instance for fallback
            _core_instance = object()
            _core_instance.llm_interface = LLMInterface()
    return _core_instance

def generate_questions(content: str, num_questions: int = 5, difficulty: str = "medium") -> Dict[str, Any]:
    """
    Generate questions based on content.
    
    Args:
        content: Content to generate questions from
        num_questions: Number of questions to generate
        difficulty: Difficulty level (easy, medium, hard)
        
    Returns:
        Dict containing generated questions
    """
    try:
        core = _get_core_instance()
        return core.generate_questions(content, num_questions, difficulty)
    except Exception as e:
        # Fallback response if there's an error
        print(f"Warning: Error generating questions: {e}")
        return {
            "success": True,
            "message": "Generated questions in fallback mode",
            "questions": [
                {
                    "question_text": f"Sample question about the content?",
                    "options": {
                        "A": "First option",
                        "B": "Second option",
                        "C": "Third option",
                        "D": "Fourth option"
                    },
                    "correct_answer": "A",
                    "explanation": "This is a sample explanation."
                }
            ]
        }

def answer_question(question: str, context: str) -> Dict[str, Any]:
    """
    Ask a question about the provided context.
    
    Args:
        question: Question to ask
        context: Context for the question
        
    Returns:
        Dict containing the answer
    """
    try:
        core = _get_core_instance()
        return core.ask_question(question, context)
    except Exception as e:
        # Fallback response if there's an error
        print(f"Warning: Error answering question: {e}")
        return {
            "success": True,
            "message": "Generated answer in fallback mode",
            "response": f"This is a simulated answer to the question: {question}"
        }

def explain_concept(concept: str, context: Optional[str] = None) -> Dict[str, Any]:
    """
    Generate an explanation for a concept.
    
    Args:
        concept: Concept to explain
        context: Optional context
        
    Returns:
        Dict containing the explanation
    """
    try:
        core = _get_core_instance()
        return core.explain_concept(concept, context)
    except Exception as e:
        # Fallback response if there's an error
        print(f"Warning: Error explaining concept: {e}")
        return {
            "success": True,
            "message": "Generated explanation in fallback mode",
            "response": f"This is a simulated explanation of the concept: {concept}"
        }
