"""
Enhanced LLM Interface with robust fallback mechanism for MentorX.
This module provides LLM functionality with graceful degradation when Ollama is unavailable.
"""

from typing import Dict, Any, List, Optional
import requests
import json
import os
import random
import time

from ..config import Config

class LLMInterface:
    """
    Interface for interacting with the Large Language Model (Mistral-7B via Ollama).
    Includes robust fallback mechanisms when Ollama is unavailable.
    """
    
    def __init__(self, api_url: Optional[str] = None):
        """
        Initialize the LLM interface.
        
        Args:
            api_url: Optional custom API URL for the LLM
        """
        self.api_url = api_url or Config.LLM_API_URL
        self.ollama_available = self._check_ollama_availability()
        
    def _check_ollama_availability(self) -> bool:
        """
        Check if Ollama is available and running.
        
        Returns:
            bool: True if Ollama is available, False otherwise
        """
        try:
            response = requests.get(
                f"{self.api_url}/version",
                timeout=getattr(Config, "OLLAMA_TIMEOUT", 5)
            )
            return response.status_code == 200
        except:
            return False
    
    def generate_response(self, prompt: str, context: Optional[str] = None, 
                         max_tokens: int = 1024) -> Dict[str, Any]:
        """
        Generate a response from the LLM based on a prompt.
        Falls back to simulated responses if Ollama is unavailable.
        
        Args:
            prompt: The prompt to send to the LLM
            context: Optional context to provide additional information
            max_tokens: Maximum number of tokens to generate
            
        Returns:
            Dict containing the LLM response
        """
        result = {
            "success": False,
            "message": "",
            "response": "",
            "tokens_used": 0,
            "using_fallback": False
        }
        
        # If Ollama is not available, use fallback immediately
        if not self.ollama_available:
            return self._generate_fallback_response(prompt, context)
        
        # Prepare the full prompt with context if provided
        full_prompt = prompt
        if context:
            full_prompt = f"Context: {context}\n\nQuestion: {prompt}"
        
        # Prepare the request payload with Ollama compatibility
        payload = {
            "model": Config.LLM_MODEL,
            "prompt": full_prompt,
            "stream": False,
            "max_tokens": max_tokens,
            "options": {
                "temperature": 0.7,
                "top_p": 0.9,
                "frequency_penalty": 0.0,
                "presence_penalty": 0.0,
                "stop": ["</answer>"],
                "timeout": getattr(Config, "OLLAMA_TIMEOUT", 60)
            }
        }
        
        try:
            # Make the API request
            response = requests.post(
                f"{self.api_url}/generate",
                headers={"Content-Type": "application/json"},
                data=json.dumps(payload),
                timeout=getattr(Config, "OLLAMA_TIMEOUT", 60)
            )
            
            # Check if the request was successful
            if response.status_code == 200:
                response_data = response.json()
                result["success"] = True
                result["response"] = response_data.get("response", "")
                result["tokens_used"] = response_data.get("eval_count", 0)
                result["message"] = "Response generated successfully"
                return result
            else:
                # If API request failed, use fallback
                return self._generate_fallback_response(prompt, context)
        
        except Exception as e:
            # If any exception occurs, use fallback
            return self._generate_fallback_response(prompt, context, error_msg=str(e))
    
    def _generate_fallback_response(self, prompt: str, context: Optional[str] = None, 
                                   error_msg: str = "Ollama service unavailable") -> Dict[str, Any]:
        """
        Generate a fallback response when Ollama is unavailable.
        
        Args:
            prompt: The original prompt
            context: Optional context
            error_msg: Error message explaining why fallback was used
            
        Returns:
            Dict containing a simulated response
        """
        # Create a simulated response based on the prompt type
        result = {
            "success": True,  # Mark as success to avoid blocking application flow
            "message": f"Using fallback response: {error_msg}",
            "response": "",
            "tokens_used": 0,
            "using_fallback": True
        }
        
        # Simulate processing time for a more realistic experience
        time.sleep(0.5)
        
        # Generate appropriate fallback based on prompt content
        if "generate questions" in prompt.lower():
            result["response"] = self._generate_fallback_questions(prompt, context)
        elif "explain" in prompt.lower() and "concept" in prompt.lower():
            result["response"] = self._generate_fallback_explanation(prompt, context)
        elif any(keyword in prompt.lower() for keyword in ["summarize", "summary", "extract"]):
            result["response"] = self._generate_fallback_summary(prompt, context)
        else:
            # Generic response for other types of prompts
            result["response"] = f"Based on your query about {prompt[:30]}..., here is a simulated response. This is using the fallback system because Ollama is currently unavailable. Please start Ollama with 'ollama serve' for full functionality."
        
        return result
    
    def _generate_fallback_questions(self, prompt: str, context: Optional[str] = None) -> str:
        """Generate fallback multiple-choice questions."""
        topics = ["general knowledge", "science", "history", "mathematics", "literature"]
        
        # Extract number of questions from prompt, default to 3
        num_questions = 3
        for part in prompt.split():
            if part.isdigit():
                num_questions = min(int(part), 5)  # Limit to 5 questions max
                break
        
        questions = []
        for i in range(1, num_questions + 1):
            topic = random.choice(topics)
            questions.append(f"""
Question {i}: This is a sample question about {topic}?
A. First option
B. Second option
C. Third option
D. Fourth option
Correct Answer: A
Explanation: This is a simulated explanation for the correct answer.
""")
        
        return "\n".join(questions) + "\n\n[Note: This is a simulated response. Start Ollama with 'ollama serve' for actual LLM-generated questions.]"
    
    def _generate_fallback_explanation(self, prompt: str, context: Optional[str] = None) -> str:
        """Generate fallback concept explanation."""
        # Extract concept from prompt
        concept = "the requested concept"
        if "concept of" in prompt:
            parts = prompt.split("concept of")
            if len(parts) > 1 and "'" in parts[1]:
                concept = parts[1].split("'")[1]
        
        return f"""
# {concept.title()}

## Definition
This is a simulated explanation of {concept}. In a real scenario with Ollama running, you would receive a detailed explanation of this concept with proper definitions, examples, and applications.

## Key Points
- First key point about {concept}
- Second key point about {concept}
- Third key point about {concept}

## Examples
Here would be examples demonstrating {concept} in action.

## Applications
Various applications of {concept} would be listed here.

[Note: This is a simulated response. Start Ollama with 'ollama serve' for actual LLM-generated explanations.]
"""
    
    def _generate_fallback_summary(self, prompt: str, context: Optional[str] = None) -> str:
        """Generate fallback content summary."""
        return f"""
# Summary of Content

This is a simulated summary of the content you provided. In a real scenario with Ollama running, you would receive an actual summary of the text extracted from your uploaded document.

## Key Points
- First key point from the content
- Second key point from the content
- Third key point from the content

## Important Concepts
- Concept 1
- Concept 2
- Concept 3

[Note: This is a simulated response. Start Ollama with 'ollama serve' for actual LLM-generated summaries.]
"""
    
    def generate_questions(self, content: str, num_questions: int = 5, 
                          difficulty: str = "medium") -> Dict[str, Any]:
        """
        Generate questions based on the provided content.
        Falls back to simulated questions if Ollama is unavailable.
        
        Args:
            content: The content to generate questions from
            num_questions: Number of questions to generate
            difficulty: Difficulty level (easy, medium, hard)
            
        Returns:
            Dict containing the generated questions
        """
        result = {
            "success": False,
            "message": "",
            "questions": [],
            "using_fallback": False
        }
        
        # If Ollama is not available, use fallback immediately
        if not self.ollama_available:
            return self._generate_fallback_question_objects(content, num_questions, difficulty)
        
        # Prepare the prompt for question generation
        prompt = f"""
        Based on the following content, generate {num_questions} multiple-choice questions at {difficulty} difficulty level.
        For each question, provide:
        1. The question text
        2. Four possible answers (A, B, C, D)
        3. The correct answer
        4. A brief explanation of why the answer is correct
        
        Content:
        {content[:2000]}  # Limit content length to avoid token limits
        
        Format each question as a JSON object.
        """
        
        # Generate response
        response_result = self.generate_response(prompt)
        
        if not response_result["success"] or response_result.get("using_fallback", False):
            # If using fallback or response failed, use structured fallback
            return self._generate_fallback_question_objects(content, num_questions, difficulty)
        
        # Process the response to extract questions
        try:
            # This is a simplified parsing approach - in a real implementation,
            # you would need more robust parsing of the LLM output
            response_text = response_result["response"]
            
            # Simple parsing for demonstration purposes
            # In a real implementation, you would need to handle various output formats
            questions = []
            current_question = {}
            
            for line in response_text.split('\n'):
                line = line.strip()
                
                if line.startswith("Question"):
                    if current_question and "question_text" in current_question:
                        questions.append(current_question)
                    current_question = {"question_text": line.split(":", 1)[1].strip() if ":" in line else line}
                
                elif line.startswith("A.") or line.startswith("A)"):
                    current_question["options"] = {"A": line.split(".", 1)[1].strip() if "." in line else line}
                
                elif line.startswith("B.") or line.startswith("B)"):
                    if "options" in current_question:
                        current_question["options"]["B"] = line.split(".", 1)[1].strip() if "." in line else line
                
                elif line.startswith("C.") or line.startswith("C)"):
                    if "options" in current_question:
                        current_question["options"]["C"] = line.split(".", 1)[1].strip() if "." in line else line
                
                elif line.startswith("D.") or line.startswith("D)"):
                    if "options" in current_question:
                        current_question["options"]["D"] = line.split(".", 1)[1].strip() if "." in line else line
                
                elif line.startswith("Correct Answer:") or line.startswith("Answer:"):
                    current_question["correct_answer"] = line.split(":", 1)[1].strip()
                
                elif line.startswith("Explanation:"):
                    current_question["explanation"] = line.split(":", 1)[1].strip()
            
            # Add the last question if it exists
            if current_question and "question_text" in current_question:
                questions.append(current_question)
            
            result["questions"] = questions
            result["success"] = len(questions) > 0
            result["message"] = f"Generated {len(questions)} questions successfully" if result["success"] else "Failed to parse questions from response"
            
            # If no questions were parsed, use fallback
            if not result["success"]:
                return self._generate_fallback_question_objects(content, num_questions, difficulty)
            
        except Exception as e:
            # If parsing fails, use fallback
            return self._generate_fallback_question_objects(content, num_questions, difficulty, error_msg=str(e))
        
        return result
    
    def _generate_fallback_question_objects(self, content: str, num_questions: int = 5, 
                                           difficulty: str = "medium", 
                                           error_msg: str = "Failed to parse questions") -> Dict[str, Any]:
        """
        Generate fallback question objects when Ollama is unavailable or parsing fails.
        
        Args:
            content: The content to generate questions from
            num_questions: Number of questions to generate
            difficulty: Difficulty level
            error_msg: Error message explaining why fallback was used
            
        Returns:
            Dict containing simulated questions
        """
        result = {
            "success": True,
            "message": f"Using fallback questions: {error_msg}",
            "questions": [],
            "using_fallback": True
        }
        
        # Extract some words from content to make questions seem related
        words = content.split()
        content_words = [word for word in words if len(word) > 4][:10]
        if not content_words:
            content_words = ["topic", "concept", "subject", "material", "content"]
        
        # Generate simulated questions
        for i in range(num_questions):
            word = random.choice(content_words) if content_words else f"topic {i+1}"
            
            question = {
                "question_text": f"Sample question about {word}?",
                "options": {
                    "A": f"First option related to {word}",
                    "B": f"Second option related to {word}",
                    "C": f"Third option related to {word}",
                    "D": f"Fourth option related to {word}"
                },
                "correct_answer": random.choice(["A", "B", "C", "D"]),
                "explanation": f"This is a simulated explanation for the correct answer about {word}.",
                "is_fallback": True
            }
            
            result["questions"].append(question)
        
        return result
    
    def explain_concept(self, concept: str, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate an explanation for a concept.
        Falls back to simulated explanation if Ollama is unavailable.
        
        Args:
            concept: The concept to explain
            context: Optional context to provide additional information
            
        Returns:
            Dict containing the explanation
        """
        prompt = f"Explain the concept of '{concept}' in detail, with examples."
        
        return self.generate_response(prompt, context)

# Add initialization function for direct import in app.py
def initialize_llm():
    """
    Initialize the LLM interface.
    
    Returns:
        LLMInterface instance
    """
    return LLMInterface()
