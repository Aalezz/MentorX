# Contributing to MentorX

Thank you for your interest in contributing to MentorX! This document provides guidelines and instructions for contributing to the project.

## Table of Contents

1. [Project Overview](#project-overview)
2. [Development Environment Setup](#development-environment-setup)
3. [Project Structure](#project-structure)
4. [Contribution Workflow](#contribution-workflow)
5. [Coding Standards](#coding-standards)
6. [Testing Guidelines](#testing-guidelines)
7. [Documentation](#documentation)
8. [Ollama Integration](#ollama-integration)

## Project Overview

MentorX is an advanced virtual learning assistant powered by Large Language Models (LLM) that provides personalized learning experiences for students, teachers, and parents. The platform features authentication with role-based access, adaptive learning capabilities, and a modern user interface.

## Development Environment Setup

### Prerequisites

- Python 3.8+
- Git
- Ollama with Mistral-7B model (version 3.7 recommended)
- Modern web browser

### Setup Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-organization/mentorx.git
   cd mentorx
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Install NLTK resources**
   ```bash
   python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"
   ```

5. **Set up Ollama**
   - Install Ollama from [https://ollama.ai/](https://ollama.ai/)
   - Pull the Mistral-7B model:
     ```bash
     ollama pull mistral-7b
     ```
   - Start the Ollama server:
     ```bash
     ollama serve
     ```

6. **Run the application**
   ```bash
   python app.py
   ```
   
7. **Access the application**
   - Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
mentorx_project/
├── src/
│   ├── content_ingestion/  # Content processing and extraction
│   │   ├── file_validator.py
│   │   ├── ingestion.py
│   │   ├── extractor.py
│   │   └── processor.py
│   ├── learning_system/    # LLM integration and question generation
│   │   ├── llm_interface.py
│   │   └── core.py
│   ├── frontend/           # User interface components
│   ├── utils/              # Shared utilities and helpers
│   └── config.py           # Configuration settings
├── frontend/               # Frontend templates and static files
│   ├── templates/          # HTML templates
│   └── static/             # CSS, JS, and other static assets
├── app.py                  # Main application entry point
├── requirements.txt        # Python dependencies
└── setup_frontend.py       # Frontend setup script
```

## Contribution Workflow

1. **Fork the repository** on GitHub.

2. **Create a new branch** for your feature or bugfix:
   ```bash
   git checkout -b feature/your-feature-name
   ```
   or
   ```bash
   git checkout -b fix/issue-description
   ```

3. **Make your changes** following the coding standards.

4. **Test your changes** thoroughly.

5. **Commit your changes** with clear, descriptive commit messages:
   ```bash
   git commit -m "Add feature: description of the feature"
   ```

6. **Push your branch** to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Create a Pull Request** from your fork to the main repository.

8. **Address review feedback** if requested by maintainers.

## Coding Standards

### Python

- Follow PEP 8 style guide
- Use type hints where appropriate
- Write docstrings for all functions, classes, and modules
- Keep functions focused on a single responsibility
- Use meaningful variable and function names

### JavaScript

- Follow ESLint recommendations
- Use camelCase for variable and function names
- Add comments for complex logic
- Prefer ES6+ features when appropriate

### HTML/CSS

- Use semantic HTML elements
- Follow BEM methodology for CSS class naming
- Ensure responsive design works on all device sizes
- Maintain accessibility standards (WCAG)

## Testing Guidelines

- Write unit tests for new functionality
- Ensure all tests pass before submitting a pull request
- Test across different browsers and devices when making UI changes
- Include test cases for edge cases and error handling

## Documentation

- Update relevant documentation when changing functionality
- Document API endpoints with clear descriptions of parameters and responses
- Include examples where helpful
- Keep the README and other documentation files up to date

## Ollama Integration

MentorX uses Ollama to integrate with the Mistral-7B language model. When working with the LLM integration:

- Ensure Ollama is running before testing LLM features
- Use the LLMInterface class in `src/learning_system/llm_interface.py` for all LLM interactions
- Be mindful of token limits and response times
- Test with different prompts to ensure robust responses
- For Ollama 3.7 compatibility, ensure you're using the latest API endpoints and parameters

## Getting Help

If you have questions or need assistance, please:
- Check existing documentation
- Look for similar issues in the issue tracker
- Reach out to the maintainers

Thank you for contributing to MentorX!
