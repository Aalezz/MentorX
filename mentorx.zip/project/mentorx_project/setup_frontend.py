from pathlib import Path
import os

# Create necessary directories for frontend
frontend_dir = Path('/home/ubuntu/mentorx_project/frontend')
templates_dir = frontend_dir / 'templates'
static_dir = frontend_dir / 'static'
css_dir = static_dir / 'css'
js_dir = static_dir / 'js'

os.makedirs(templates_dir, exist_ok=True)
os.makedirs(css_dir, exist_ok=True)
os.makedirs(js_dir, exist_ok=True)

print(f"Created frontend directory structure at {frontend_dir}")
