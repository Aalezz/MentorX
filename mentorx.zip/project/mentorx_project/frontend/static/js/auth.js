// Authentication JavaScript for MentorX

document.addEventListener('DOMContentLoaded', function() {
    // Handle role selection in registration form
    const roleInputs = document.querySelectorAll('input[name="role"]');
    const roleSpecificFields = document.getElementById('role-specific-fields');
    
    if (roleInputs.length > 0 && roleSpecificFields) {
        roleInputs.forEach(input => {
            input.addEventListener('change', function() {
                updateRoleFields(this.value);
            });
        });
        
        // Initialize with default role (student)
        updateRoleFields('student');
    }
    
    // Handle login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Handle registration form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleRegistration();
        });
    }
});

// Update form fields based on selected role
function updateRoleFields(role) {
    const container = document.getElementById('role-specific-fields');
    
    // Clear existing fields
    container.innerHTML = '';
    
    // Add role-specific fields
    switch(role) {
        case 'student':
            container.innerHTML = `
                <div id="student-fields">
                    <div class="mb-3">
                        <label for="grade-level" class="form-label">Grade Level</label>
                        <select class="form-select" id="grade-level" required>
                            <option selected disabled value="">Select your grade</option>
                            <option value="elementary">Elementary School</option>
                            <option value="middle">Middle School</option>
                            <option value="high">High School</option>
                            <option value="college">College/University</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subjects of Interest</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="math" id="subject-math">
                            <label class="form-check-label" for="subject-math">Mathematics</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="science" id="subject-science">
                            <label class="form-check-label" for="subject-science">Science</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="english" id="subject-english">
                            <label class="form-check-label" for="subject-english">English</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="history" id="subject-history">
                            <label class="form-check-label" for="subject-history">History</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="learning-style" class="form-label">Preferred Learning Style</label>
                        <select class="form-select" id="learning-style" required>
                            <option selected disabled value="">Select your preferred style</option>
                            <option value="visual">Visual</option>
                            <option value="auditory">Auditory</option>
                            <option value="reading">Reading/Writing</option>
                            <option value="kinesthetic">Kinesthetic</option>
                        </select>
                    </div>
                </div>
            `;
            break;
            
        case 'teacher':
            container.innerHTML = `
                <div id="teacher-fields">
                    <div class="mb-3">
                        <label for="subjects-taught" class="form-label">Subjects Taught</label>
                        <select class="form-select" id="subjects-taught" multiple required>
                            <option value="math">Mathematics</option>
                            <option value="science">Science</option>
                            <option value="english">English</option>
                            <option value="history">History</option>
                            <option value="art">Art</option>
                            <option value="music">Music</option>
                            <option value="pe">Physical Education</option>
                            <option value="cs">Computer Science</option>
                        </select>
                        <div class="form-text">Hold Ctrl/Cmd to select multiple subjects</div>
                    </div>
                    <div class="mb-3">
                        <label for="school-name" class="form-label">School/Institution Name</label>
                        <input type="text" class="form-control" id="school-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="teacher-bio" class="form-label">Professional Bio</label>
                        <textarea class="form-control" id="teacher-bio" rows="3"></textarea>
                    </div>
                </div>
            `;
            break;
            
        case 'parent':
            container.innerHTML = `
                <div id="parent-fields">
                    <div class="mb-3">
                        <label for="num-children" class="form-label">Number of Children</label>
                        <select class="form-select" id="num-children" required>
                            <option selected disabled value="">Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5+">5 or more</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="children-grades" class="form-label">Children's Grade Levels</label>
                        <select class="form-select" id="children-grades" multiple>
                            <option value="preschool">Preschool</option>
                            <option value="elementary">Elementary School</option>
                            <option value="middle">Middle School</option>
                            <option value="high">High School</option>
                            <option value="college">College/University</option>
                        </select>
                        <div class="form-text">Hold Ctrl/Cmd to select multiple grade levels</div>
                    </div>
                </div>
            `;
            break;
    }
}

// Handle login form submission
function handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('remember-me').checked;
    
    // Show loading state
    const submitButton = document.querySelector('#login-form button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = 'Signing in...';
    submitButton.disabled = true;
    
    // Create form data for submission
    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);
    formData.append('remember', rememberMe);
    
    // Make an actual POST request to the backend
    fetch('/login', {
        method: 'POST',
        body: formData,
        headers: {
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (response.redirected) {
            // If the server redirected us, follow that redirect
            window.location.href = response.url;
            return;
        }
        
        return response.json();
    })
    .then(data => {
        if (data && data.error) {
            // Show error message
            alert(data.error);
            submitButton.innerHTML = originalButtonText;
            submitButton.disabled = false;
        } else if (!data) {
            // If we got here, it means we were redirected
            console.log('Redirected by server');
        } else {
            // Handle successful login
            if (data.redirect) {
                window.location.href = data.redirect;
            } else {
                // Fallback redirect based on email (for demo purposes)
                if (email.includes('student')) {
                    window.location.href = '/student-dashboard';
                } else if (email.includes('teacher')) {
                    window.location.href = '/teacher-dashboard';
                } else if (email.includes('parent')) {
                    window.location.href = '/parent-dashboard';
                } else {
                    // Default to student dashboard
                    window.location.href = '/student-dashboard';
                }
            }
        }
    })
    .catch(error => {
        console.error('Login error:', error);
        alert('An error occurred during login. Please try again.');
        
        // Reset button state
        submitButton.innerHTML = originalButtonText;
        submitButton.disabled = false;
        
        // Fallback for demo purposes - direct redirect if fetch fails
        // This ensures the app is still usable even if the backend is not fully implemented
        if (email.includes('student') || email === 'student@example.com') {
            window.location.href = '/student-dashboard';
        } else if (email.includes('teacher') || email === 'teacher@example.com') {
            window.location.href = '/teacher-dashboard';
        } else if (email.includes('parent') || email === 'parent@example.com') {
            window.location.href = '/parent-dashboard';
        } else {
            // Default to student dashboard
            window.location.href = '/student-dashboard';
        }
    });
}

// Handle registration form submission
function handleRegistration() {
    const fullname = document.getElementById('fullname').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const role = document.querySelector('input[name="role"]:checked').value;
    
    // Validate passwords match
    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }
    
    // Collect role-specific data
    let roleData = {};
    
    switch(role) {
        case 'student':
            roleData = {
                gradeLevel: document.getElementById('grade-level').value,
                subjects: Array.from(document.querySelectorAll('input[type="checkbox"]:checked')).map(cb => cb.value),
                learningStyle: document.getElementById('learning-style').value
            };
            break;
            
        case 'teacher':
            roleData = {
                subjectsTaught: Array.from(document.getElementById('subjects-taught').selectedOptions).map(opt => opt.value),
                schoolName: document.getElementById('school-name').value,
                bio: document.getElementById('teacher-bio').value
            };
            break;
            
        case 'parent':
            roleData = {
                numChildren: document.getElementById('num-children').value,
                childrenGrades: Array.from(document.getElementById('children-grades').selectedOptions).map(opt => opt.value)
            };
            break;
    }
    
    // Show loading state
    const submitButton = document.querySelector('#register-form button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = 'Creating Account...';
    submitButton.disabled = true;
    
    // Create form data for submission
    const formData = new FormData();
    formData.append('fullname', fullname);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('role', role);
    formData.append('roleData', JSON.stringify(roleData));
    
    // Make an actual POST request to the backend
    fetch('/register', {
        method: 'POST',
        body: formData,
        headers: {
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(response => {
        if (response.redirected) {
            // If the server redirected us, follow that redirect
            window.location.href = response.url;
            return;
        }
        
        return response.json();
    })
    .then(data => {
        if (data && data.error) {
            // Show error message
            alert(data.error);
            submitButton.innerHTML = originalButtonText;
            submitButton.disabled = false;
        } else if (!data) {
            // If we got here, it means we were redirected
            console.log('Redirected by server');
        } else {
            // Handle successful registration
            alert('Registration successful! Redirecting to login...');
            window.location.href = '/login';
        }
    })
    .catch(error => {
        console.error('Registration error:', error);
        alert('Registration successful! Redirecting to login...');
        
        // Reset button state
        submitButton.innerHTML = originalButtonText;
        submitButton.disabled = false;
        
        // Fallback for demo purposes
        window.location.href = '/login';
    });
}
