// Main JavaScript for MentorX application

document.addEventListener('DOMContentLoaded', function() {
    // Navigation handling
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active nav link
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding section
            const targetId = this.id.replace('-nav', '-section');
            sections.forEach(section => {
                section.classList.add('d-none');
                if (section.id === targetId) {
                    section.classList.remove('d-none');
                }
            });
        });
    });
    
    // File Upload Form
    const uploadForm = document.getElementById('upload-form');
    const uploadResult = document.getElementById('upload-result');
    const uploadStatus = document.getElementById('upload-status');
    const contentText = document.getElementById('content-text');
    const termsList = document.getElementById('terms-list');
    
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const fileInput = document.getElementById('file-upload');
        const file = fileInput.files[0];
        
        if (!file) {
            alert('Please select a file to upload');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        
        // Show loading state
        uploadStatus.innerHTML = '<div class="alert alert-info">Processing file... This may take a moment.</div>';
        uploadResult.classList.remove('d-none');
        
        fetch('/api/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                uploadStatus.innerHTML = '<div class="alert alert-success">File processed successfully!</div>';
                
                // Display content preview if available
                if (data.stages && data.stages.extraction && data.stages.extraction.content) {
                    const content = data.stages.extraction.content;
                    contentText.textContent = content.length > 1000 ? content.substring(0, 1000) + '...' : content;
                }
                
                // Display key terms if available
                if (data.stages && data.stages.processing && data.stages.processing.key_terms) {
                    const terms = data.stages.processing.key_terms;
                    termsList.innerHTML = '';
                    terms.forEach(term => {
                        const badge = document.createElement('span');
                        badge.className = 'badge bg-primary';
                        badge.textContent = term;
                        termsList.appendChild(badge);
                    });
                }
                
                // Store content for other sections
                sessionStorage.setItem('uploadedContent', data.stages.extraction.content);
            } else {
                uploadStatus.innerHTML = `<div class="alert alert-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            uploadStatus.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
        });
    });
    
    // Generate Questions Form
    const questionsForm = document.getElementById('questions-form');
    const questionsResult = document.getElementById('questions-result');
    const questionsContainer = document.getElementById('questions-container');
    
    questionsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const content = document.getElementById('question-content').value || sessionStorage.getItem('uploadedContent');
        const numQuestions = document.getElementById('num-questions').value;
        const difficulty = document.getElementById('difficulty').value;
        
        if (!content) {
            alert('Please provide content or upload a file first');
            return;
        }
        
        // Show loading state
        questionsContainer.innerHTML = '<div class="alert alert-info">Generating questions... This may take a moment.</div>';
        questionsResult.classList.remove('d-none');
        
        fetch('/api/generate-questions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: content,
                num_questions: parseInt(numQuestions),
                difficulty: difficulty
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                questionsContainer.innerHTML = '';
                
                data.questions.forEach((question, index) => {
                    const questionCard = document.createElement('div');
                    questionCard.className = 'card question-card mb-3';
                    
                    let optionsHtml = '';
                    if (question.options) {
                        for (const [key, value] of Object.entries(question.options)) {
                            const isCorrect = question.correct_answer && question.correct_answer.includes(key);
                            optionsHtml += `
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="q${index}" id="q${index}${key}" ${isCorrect ? 'checked' : ''} disabled>
                                    <label class="form-check-label ${isCorrect ? 'correct-answer' : ''}" for="q${index}${key}">
                                        ${key}. ${value}
                                    </label>
                                </div>
                            `;
                        }
                    }
                    
                    questionCard.innerHTML = `
                        <div class="card-body">
                            <h5 class="card-title">Question ${index + 1}</h5>
                            <p class="card-text">${question.question_text}</p>
                            <div class="options-container mb-3">
                                ${optionsHtml}
                            </div>
                            <div class="explanation">
                                <strong>Explanation:</strong> ${question.explanation || 'No explanation provided'}
                            </div>
                        </div>
                    `;
                    
                    questionsContainer.appendChild(questionCard);
                });
            } else {
                questionsContainer.innerHTML = `<div class="alert alert-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            questionsContainer.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
        });
    });
    
    // Ask Question Form
    const askForm = document.getElementById('ask-form');
    const askResult = document.getElementById('ask-result');
    const answerContainer = document.getElementById('answer-container');
    
    askForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const context = document.getElementById('context').value || sessionStorage.getItem('uploadedContent');
        const question = document.getElementById('question').value;
        
        if (!context) {
            alert('Please provide context or upload a file first');
            return;
        }
        
        if (!question) {
            alert('Please enter a question');
            return;
        }
        
        // Show loading state
        answerContainer.innerHTML = '<div class="alert alert-info">Generating answer... This may take a moment.</div>';
        askResult.classList.remove('d-none');
        
        fetch('/api/ask-question', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                question: question,
                context: context
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                answerContainer.innerHTML = `
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Question</h5>
                            <p class="card-text">${question}</p>
                            <h5 class="card-title mt-4">Answer</h5>
                            <p class="card-text">${data.response}</p>
                        </div>
                    </div>
                `;
            } else {
                answerContainer.innerHTML = `<div class="alert alert-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            answerContainer.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
        });
    });
    
    // Explain Concept Form
    const explainForm = document.getElementById('explain-form');
    const explainResult = document.getElementById('explain-result');
    const explanationContainer = document.getElementById('explanation-container');
    
    explainForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const concept = document.getElementById('concept').value;
        const context = document.getElementById('concept-context').value || sessionStorage.getItem('uploadedContent');
        
        if (!concept) {
            alert('Please enter a concept to explain');
            return;
        }
        
        // Show loading state
        explanationContainer.innerHTML = '<div class="alert alert-info">Generating explanation... This may take a moment.</div>';
        explainResult.classList.remove('d-none');
        
        fetch('/api/explain-concept', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                concept: concept,
                context: context
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                explanationContainer.innerHTML = `
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Concept: ${concept}</h5>
                            <p class="card-text">${data.response}</p>
                        </div>
                    </div>
                `;
            } else {
                explanationContainer.innerHTML = `<div class="alert alert-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            explanationContainer.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
        });
    });
});
