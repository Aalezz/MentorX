// Dashboard JavaScript for MentorX - Enhanced with Fixes

document.addEventListener("DOMContentLoaded", function() {
    // --- Common Functionality ---
    initializeSidebarToggle();
    initializeSectionNavigation();
    initializeDropdowns(); // Handle profile/notification dropdowns

    // --- Role-Specific Initialization ---
    if (document.body.classList.contains("student-dashboard")) {
        initializeStudentDashboard();
    } else if (document.body.classList.contains("teacher-dashboard")) {
        initializeTeacherDashboard();
    } else if (document.body.classList.contains("parent-dashboard")) {
        initializeParentDashboard();
    }

    // --- Populate Empty Sections ---
    populateEmptySections();
});

// --- Common Initialization Functions ---

function initializeSidebarToggle() {
    const sidebarCollapse = document.getElementById("sidebarCollapse");
    const sidebar = document.getElementById("sidebar");
    if (sidebarCollapse && sidebar) {
        sidebarCollapse.addEventListener("click", function() {
            sidebar.classList.toggle("active");
            // Optional: Add body class for content adjustment
            document.body.classList.toggle("sidebar-active"); 
        });
    }
}

function initializeSectionNavigation() {
    const navLinks = document.querySelectorAll("#sidebar .nav-link");
    const dashboardSections = document.querySelectorAll(".dashboard-content");
    const defaultSectionId = "#dashboardContent"; // Default section to show

    // Function to show a specific section
    const showSection = (targetId) => {
        dashboardSections.forEach(section => {
            section.classList.add("d-none");
        });
        const targetSection = document.querySelector(targetId);
        if (targetSection) {
            targetSection.classList.remove("d-none");
        } else {
            // Fallback to default if target not found
            const defaultSection = document.querySelector(defaultSectionId);
            if (defaultSection) defaultSection.classList.remove("d-none");
        }
        // Update active link
        navLinks.forEach(l => {
            l.parentElement.classList.remove("active");
            if (l.getAttribute("href") === targetId) {
                l.parentElement.classList.add("active");
            }
        });
        // Store the active section
        sessionStorage.setItem("activeSection", targetId);
    };

    // Add click listeners to nav links
    navLinks.forEach(link => {
        link.addEventListener("click", function(e) {
            const targetId = this.getAttribute("href");
            if (targetId && targetId.startsWith("#")) {
                e.preventDefault();
                showSection(targetId);
            }
            // Allow external links (like logout) to proceed
        });
    });

    // Show the correct section on page load
    const activeSection = sessionStorage.getItem("activeSection");
    if (activeSection && document.querySelector(activeSection)) {
        showSection(activeSection);
    } else {
        showSection(defaultSectionId); // Show default section
    }
}

function initializeDropdowns() {
    // Profile/Account Settings Dropdown Items
    document.querySelectorAll(".dropdown-menu a[href=\"#\"]").forEach(item => {
        // Exclude notification items for now
        if (!item.closest(".notification-badge")) { 
            item.addEventListener("click", (e) => {
                e.preventDefault();
                const actionText = e.target.textContent;
                if (actionText === "My Profile" || actionText === "Account Settings") {
                    // Try to navigate to settings section if it exists
                    const settingsLink = document.querySelector("a.nav-link[href=\"#settingsContent\"]");
                    if (settingsLink) {
                        settingsLink.click(); // Simulate click to navigate
                    } else {
                        alert(`"${actionText}" feature coming soon!`);
                    }
                } else {
                     alert(`"${actionText}" feature coming soon!`);
                }
            });
        }
    });

    // Notification Dropdown Items
    document.querySelectorAll(".notification-badge .dropdown-item").forEach(item => {
        item.addEventListener("click", (e) => {
            e.preventDefault();
            alert(`Viewing notification: "${e.target.textContent}" (Functionality coming soon)`);
            // Future: Mark as read, navigate to relevant content
        });
    });
}

function populateEmptySections() {
    const emptySections = {
        // Student
        "#settingsContent.student-dashboard": "Account settings and preferences will be available here.",
        // Teacher
        "#myClassesContent": "Manage your classes, view rosters, and track overall class progress here.",
        "#studentsContent": "View detailed information about your students, their performance, and learning styles.",
        "#assignmentsContent": "Create, assign, and grade assignments for your classes.",
        "#assessmentsContent": "Create quizzes, tests, and other assessments. View results and analytics.",
        "#messagesContent.teacher-dashboard": "Communicate with students and parents.",
        "#settingsContent.teacher-dashboard": "Manage your teacher profile, notification settings, and other preferences.",
        // Parent
        "#myChildrenContent": "View detailed progress reports and activity for each of your children.",
        "#progressReportsContent": "Access detailed academic reports, grades, and teacher feedback.",
        "#assignmentsContent.parent-dashboard": "Track upcoming and past assignments for your children.",
        "#messagesContent.parent-dashboard": "Communicate directly with your children\'s teachers.",
        "#learningResourcesContent": "Find or upload supplementary learning materials for your children.",
        "#settingsContent.parent-dashboard": "Manage your parent account, notification preferences, and linked children."
    };

    for (const selector in emptySections) {
        const section = document.querySelector(selector);
        // Check if the section exists and is currently empty or has only placeholder comments
        if (section && section.children.length === 0 || (section.children.length === 1 && section.children[0].nodeType === Node.COMMENT_NODE)) {
            section.innerHTML = `<div class="container-fluid p-4"><div class="alert alert-info">${emptySections[selector]} (Feature coming soon)</div></div>`;
        }
    }
}

// --- Student Dashboard Initialization ---
function initializeStudentDashboard() {
    console.log("Initializing Student Dashboard...");
    initializeStudentForms();
    initializeStudentButtons();
    initializeStudentTooltips();
}

function initializeStudentForms() {
    // Upload Form (Existing logic seems okay, ensure elements exist)
    const uploadForm = document.getElementById("upload-form");
    if (uploadForm) {
        // Existing fetch logic... 
        // Add better feedback
        uploadForm.addEventListener("submit", (e) => {
            const uploadStatus = document.getElementById("upload-status");
            if (uploadStatus) uploadStatus.innerHTML = 
                `<div class="d-flex align-items-center alert alert-info">
                  <strong role="status">Processing...</strong>
                  <div class="spinner-border ms-auto spinner-border-sm" aria-hidden="true"></div>
                </div>`;
            // Existing fetch logic follows...
        });
    } else {
        console.warn("Student Upload Form not found");
    }

    // Question Generation Form (Existing logic seems okay, ensure elements exist)
    const questionForm = document.getElementById("question-form");
    if (questionForm) {
        // Existing fetch logic...
        // Add better feedback
        questionForm.addEventListener("submit", (e) => {
            const questionsList = document.getElementById("questions-list");
            if (questionsList) questionsList.innerHTML = 
                `<div class="d-flex align-items-center alert alert-info">
                  <strong role="status">Generating Questions...</strong>
                  <div class="spinner-border ms-auto spinner-border-sm" aria-hidden="true"></div>
                </div>`;
            // Existing fetch logic follows...
        });
    } else {
        console.warn("Student Question Form not found");
    }

    // Ask Question Form (Existing logic seems okay, ensure elements exist)
    const askForm = document.getElementById("ask-form");
    if (askForm) {
        // Existing fetch logic...
        // Add better feedback
        askForm.addEventListener("submit", (e) => {
            const answerText = document.getElementById("answer-text");
            if (answerText) answerText.innerHTML = 
                `<div class="d-flex align-items-center alert alert-info">
                  <strong role="status">Thinking...</strong>
                  <div class="spinner-border ms-auto spinner-border-sm" aria-hidden="true"></div>
                </div>`;
            // Existing fetch logic follows...
        });
    } else {
        console.warn("Student Ask Form not found");
    }

    // Explain Concept Form (Existing logic seems okay, ensure elements exist)
    const conceptForm = document.getElementById("concept-form");
    if (conceptForm) {
        // Existing fetch logic...
        // Add better feedback
        conceptForm.addEventListener("submit", (e) => {
            const explanationText = document.getElementById("explanation-text");
            if (explanationText) explanationText.innerHTML = 
                `<div class="d-flex align-items-center alert alert-info">
                  <strong role="status">Generating Explanation...</strong>
                  <div class="spinner-border ms-auto spinner-border-sm" aria-hidden="true"></div>
                </div>`;
            // Existing fetch logic follows...
        });
    } else {
        console.warn("Student Concept Form not found");
    }
}

function initializeStudentButtons() {
    // Continue Learning Button
    const continueLearningBtn = document.querySelector(".learning-path .btn-primary");
    if (continueLearningBtn) {
        continueLearningBtn.addEventListener("click", (e) => {
            e.preventDefault();
            alert("Continuing your learning path! (Functionality coming soon)");
            // Future: Navigate to the current learning module
        });
    }

    // Upcoming Task View Details Buttons
    document.querySelectorAll(".task-list .btn-outline-secondary").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const taskTitle = e.target.closest(".task-item").querySelector("h6").textContent;
            alert(`Viewing details for: ${taskTitle} (Functionality coming soon)`);
            // Future: Show a modal with task details
        });
    });
    
    // Save Questions Button (Fix alert message)
    const saveQuestionsBtn = document.getElementById("save-questions-btn");
     if (saveQuestionsBtn) {
         saveQuestionsBtn.addEventListener("click", function() {
             alert("Save Questions feature coming soon!"); // Updated alert
         });
     }
}

function initializeStudentTooltips() {
    // Learning Style Badge Tooltip
    const learningStyleBadge = document.querySelector(".learning-style-badge .badge");
    if (learningStyleBadge && bootstrap.Tooltip) { // Check if Bootstrap Tooltip is loaded
        new bootstrap.Tooltip(learningStyleBadge, {
            title: "This indicates your preferred learning style, identified by MentorX to personalize your experience.",
            placement: "bottom"
        });
    }
}

// --- Teacher Dashboard Initialization ---
function initializeTeacherDashboard() {
    console.log("Initializing Teacher Dashboard...");
    initializeTeacherForms();
    initializeTeacherButtons();
    initializeTeacherCharts(); // Placeholder for potential charts
}

function initializeTeacherForms() {
    // Teacher Upload Form (Add feedback, check existing logic)
    const teacherUploadForm = document.getElementById("teacher-upload-form");
    if (teacherUploadForm) {
        teacherUploadForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const fileInput = document.getElementById("teacher-file-upload");
            const file = fileInput.files[0];
            if (!file) { alert("Please select a file."); return; }
            
            const uploadStatus = document.getElementById("teacher-upload-status");
            if (uploadStatus) uploadStatus.innerHTML = 
                `<div class="d-flex align-items-center alert alert-info">
                  <strong role="status">Processing...</strong>
                  <div class="spinner-border ms-auto spinner-border-sm" aria-hidden="true"></div>
                </div>`;
            
            const formData = new FormData();
            formData.append("file", file);
            
            // Assuming /api/upload works for teachers too
            fetch("/api/upload", { method: "POST", body: formData })
                .then(response => response.json())
                .then(data => {
                    const uploadResult = document.getElementById("teacher-upload-result");
                    const contentText = document.getElementById("teacher-content-text");
                    const termsList = document.getElementById("teacher-terms-list");
                    
                    if (uploadResult) uploadResult.classList.remove("d-none");
                    
                    if (data.success) {
                        if (uploadStatus) uploadStatus.innerHTML = 
                            `<div class="alert alert-success">File processed successfully!</div>`;
                        if (contentText) contentText.textContent = data.content ? (data.content.length > 500 ? data.content.substring(0, 500) + "..." : data.content) : "No content preview.";
                        if (termsList) {
                            termsList.innerHTML = "";
                            if (data.key_terms && data.key_terms.length > 0) {
                                data.key_terms.forEach(term => {
                                    const badge = document.createElement("span");
                                    badge.className = "badge bg-primary me-2";
                                    badge.textContent = term;
                                    termsList.appendChild(badge);
                                });
                            } else {
                                termsList.innerHTML = "<p>No key terms identified.</p>";
                            }
                        }
                    } else {
                        if (uploadStatus) uploadStatus.innerHTML = 
                            `<div class="alert alert-danger">Error: ${data.error || "Upload failed"}</div>`;
                    }
                })
                .catch(error => {
                    if (uploadStatus) uploadStatus.innerHTML = 
                        `<div class="alert alert-danger">Error: ${error.message || "Network error"}</div>`;
                    console.error("Teacher upload error:", error);
                });
        });
    } else {
        console.warn("Teacher Upload Form not found");
    }
}

function initializeTeacherButtons() {
    // Create New Class Button
    const createClassBtn = document.getElementById("createClassBtn");
    if (createClassBtn) {
        createClassBtn.addEventListener("click", function() {
            // Replace alert with modal or navigation
            alert("Create New Class feature coming soon!");
            // Example: Show a modal
            // const createClassModal = new bootstrap.Modal(document.getElementById("createClassModal"));
            // createClassModal.show();
        });
    }

    // View All Links (e.g., in Class Performance, Recent Submissions)
    document.querySelectorAll(".teacher-dashboard .card-footer a, .teacher-dashboard .view-all-link").forEach(link => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const sectionTitle = e.target.closest(".card").querySelector(".card-header h5").textContent;
            alert(`Viewing all ${sectionTitle}... (Functionality coming soon)`);
            // Future: Navigate to a dedicated page or expand the list
        });
    });

    // Class Dropdown Filters
    const classFilterDropdown = document.querySelector("#dashboardContent .dropdown-menu"); // Adjust selector if needed
    if (classFilterDropdown) {
        classFilterDropdown.querySelectorAll(".dropdown-item").forEach(item => {
            item.addEventListener("click", (e) => {
                e.preventDefault();
                const selectedClass = e.target.textContent;
                const dropdownButton = e.target.closest(".dropdown").querySelector("button");
                dropdownButton.textContent = selectedClass; // Update button text
                alert(`Filtering by ${selectedClass}... (Functionality coming soon)`);
                // Future: Fetch and update table/chart data based on selection
            });
        });
    }

    // View Profile Buttons (e.g., in Recent Submissions)
    document.querySelectorAll(".submission-list .btn-outline-primary").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const studentName = e.target.closest(".submission-item").querySelector("h6").textContent;
            alert(`Viewing profile for ${studentName}... (Functionality coming soon)`);
            // Future: Navigate to student detail page/section
        });
    });
}

function initializeTeacherCharts() {
    // Placeholder for initializing charts (e.g., using Chart.js)
    const performanceChartCanvas = document.getElementById("classPerformanceChart");
    if (performanceChartCanvas) {
        console.log("Placeholder: Initialize class performance chart here.");
        // Example: new Chart(performanceChartCanvas, { ... });
    }
    const learningStyleChartCanvas = document.getElementById("learningStyleChart");
    if (learningStyleChartCanvas) {
        console.log("Placeholder: Initialize learning style distribution chart here.");
    }
}

// --- Parent Dashboard Initialization ---
function initializeParentDashboard() {
    console.log("Initializing Parent Dashboard...");
    initializeParentButtons();
}

function initializeParentButtons() {
    // Message Teachers Button
    const messageTeachersBtn = document.getElementById("messageTeachersBtn");
    if (messageTeachersBtn) {
        messageTeachersBtn.addEventListener("click", () => {
            alert("Opening message composer... (Functionality coming soon)");
            // Future: Show a message modal or navigate to messages section
        });
    }

    // Schedule Meeting Button
    const scheduleMeetingBtn = document.getElementById("scheduleMeetingBtn");
    if (scheduleMeetingBtn) {
        scheduleMeetingBtn.addEventListener("click", () => {
            alert("Opening meeting scheduler... (Functionality coming soon)");
            // Future: Show a scheduling modal or integrate with a calendar
        });
    }

    // View Details Buttons (Children Cards)
    document.querySelectorAll(".child-card .view-details-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const childName = e.target.closest(".child-card").querySelector("h5").textContent;
            alert(`Viewing details for ${childName}... (Functionality coming soon)`);
            // Future: Navigate to a child-specific detail section or page
            // Example: Trigger navigation to #myChildrenContent and filter/display info
            // const childrenLink = document.querySelector("a.nav-link[href=\"#myChildrenContent\"]");
            // if (childrenLink) childrenLink.click(); 
        });
    });

    // View All Events/Recommendations Links
    document.querySelectorAll(".parent-dashboard .card-footer a").forEach(link => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            const sectionTitle = e.target.closest(".card").querySelector(".card-header h5").textContent;
            alert(`Viewing all ${sectionTitle}... (Functionality coming soon)`);
        });
    });
}

// --- Helper Functions ---

// Example: Function to show a generic modal (requires Bootstrap JS)
function showInfoModal(title, message) {
    // Check if modal exists, if not, create it dynamically (or ensure it's in the base HTML)
    let modalElement = document.getElementById("infoModal");
    if (!modalElement) {
        // Create modal structure (simplified)
        modalElement = document.createElement("div");
        modalElement.innerHTML = `
            <div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="infoModalLabel">Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <p id="infoModalMessage"></p>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>`;
        document.body.appendChild(modalElement.firstElementChild);
        modalElement = document.getElementById("infoModal"); // Re-select after appending
    }

    const modalTitle = modalElement.querySelector(".modal-title");
    const modalMessage = modalElement.querySelector("#infoModalMessage");
    
    if(modalTitle) modalTitle.textContent = title;
    if(modalMessage) modalMessage.textContent = message;

    const modalInstance = bootstrap.Modal.getOrCreateInstance(modalElement);
    modalInstance.show();
}

// --- Existing API Fetch Logic (Keep as is, ensure forms/elements exist) ---
// The existing fetch logic for student upload, question generation, ask question, 
// and explain concept seems mostly functional based on the previous file read.
// Ensure the corresponding HTML elements (forms, result divs) exist in the student dashboard.
// Add similar fetch logic for teacher/parent features if backend endpoints exist.

console.log("Enhanced dashboard.js loaded.");

