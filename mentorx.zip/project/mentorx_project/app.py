import os
from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.content_ingestion.file_validator import validate_file
from src.content_ingestion.ingestion import ingest_content
from src.content_ingestion.extractor import extract_content
from src.content_ingestion.processor import process_content
from src.learning_system.core import generate_questions, answer_question, explain_concept
from src.learning_system.llm_interface import initialize_llm

app = Flask(__name__, 
            static_folder='frontend/static',
            template_folder='frontend/templates')

# Secret key for session management
app.secret_key = os.urandom(24)

# Initialize LLM
initialize_llm()

# Mock user database for demonstration
users = {
    "student@example.com": {"password": "password123", "role": "student", "name": "Alex Johnson"},
    "teacher@example.com": {"password": "password123", "role": "teacher", "name": "Dr. Sarah Miller"},
    "parent@example.com": {"password": "password123", "role": "parent", "name": "Robert Thompson"}
}

# Original routes
@app.route('/')
def index():
    # Check if user is logged in
    if 'user_email' in session:
        role = users.get(session['user_email'], {}).get('role')
        if role == 'student':
            return redirect(url_for('student_dashboard'))
        elif role == 'teacher':
            return redirect(url_for('teacher_dashboard'))
        elif role == 'parent':
            return redirect(url_for('parent_dashboard'))
    
    # If not logged in, redirect to login page
    return redirect(url_for('login'))

@app.route('/original')
def original_index():
    # Original index page for backward compatibility
    return render_template('index.html')

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if this is an AJAX request
        is_ajax = request.headers.get('Accept') == 'application/json'
        
        if email in users and users[email]['password'] == password:
            session['user_email'] = email
            role = users[email]['role']
            
            # For AJAX requests, return JSON response
            if is_ajax:
                redirect_url = ''
                if role == 'student':
                    redirect_url = url_for('student_dashboard')
                elif role == 'teacher':
                    redirect_url = url_for('teacher_dashboard')
                elif role == 'parent':
                    redirect_url = url_for('parent_dashboard')
                return jsonify({'success': True, 'redirect': redirect_url})
            
            # For regular form submissions, redirect
            if role == 'student':
                return redirect(url_for('student_dashboard'))
            elif role == 'teacher':
                return redirect(url_for('teacher_dashboard'))
            elif role == 'parent':
                return redirect(url_for('parent_dashboard'))
        else:
            # For AJAX requests, return JSON error
            if is_ajax:
                return jsonify({'error': 'Invalid email or password'})
            
            # For regular form submissions, flash message
            flash('Invalid email or password')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # In a real application, this would save the user to a database
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        name = request.form.get('fullname')
        
        # Check if this is an AJAX request
        is_ajax = request.headers.get('Accept') == 'application/json'
        
        # For AJAX requests, return JSON response
        if is_ajax:
            return jsonify({'success': True, 'message': 'Registration successful!'})
        
        # For regular form submissions, flash message and redirect
        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_email', None)
    return redirect(url_for('login'))

# Role-specific dashboard routes
@app.route('/student-dashboard')
def student_dashboard():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    user_data = users.get(session['user_email'], {})
    if user_data.get('role') != 'student':
        return redirect(url_for('login'))
    
    return render_template('student_dashboard.html', user=user_data)

@app.route('/teacher-dashboard')
def teacher_dashboard():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    user_data = users.get(session['user_email'], {})
    if user_data.get('role') != 'teacher':
        return redirect(url_for('login'))
    
    return render_template('teacher_dashboard.html', user=user_data)

@app.route('/parent-dashboard')
def parent_dashboard():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    user_data = users.get(session['user_email'], {})
    if user_data.get('role') != 'parent':
        return redirect(url_for('login'))
    
    return render_template('parent_dashboard.html', user=user_data)

# API routes for content processing
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    # Validate file
    validation_result = validate_file(file)
    if not validation_result['valid']:
        return jsonify({'error': validation_result['message']}), 400
    
    # Process file
    try:
        # Save file temporarily
        temp_path = os.path.join('uploads', file.filename)
        os.makedirs('uploads', exist_ok=True)
        file.save(temp_path)
        
        # Ingest content
        ingestion_result = ingest_content(temp_path)
        
        # Extract content
        extraction_result = extract_content(ingestion_result['file_path'], ingestion_result['file_type'])
        
        # Process content
        processing_result = process_content(extraction_result['content'])
        
        # Return results
        return jsonify({
            'success': True,
            'content': processing_result['processed_content'],
            'key_terms': processing_result['key_terms']
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate-questions', methods=['POST'])
def api_generate_questions():
    data = request.json
    content = data.get('content', '')
    num_questions = data.get('num_questions', 5)
    difficulty = data.get('difficulty', 'medium')
    
    questions = generate_questions(content, num_questions, difficulty)
    
    return jsonify({
        'success': True,
        'questions': questions
    })

@app.route('/api/ask-question', methods=['POST'])
def api_ask_question():
    data = request.json
    question = data.get('question', '')
    context = data.get('context', '')
    
    answer = answer_question(question, context)
    
    return jsonify({
        'success': True,
        'answer': answer
    })

@app.route('/api/explain-concept', methods=['POST'])
def api_explain_concept():
    data = request.json
    concept = data.get('concept', '')
    context = data.get('context', '')
    
    explanation = explain_concept(concept, context)
    
    return jsonify({
        'success': True,
        'explanation': explanation
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
