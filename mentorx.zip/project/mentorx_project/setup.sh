#!/bin/bash

# MentorX Project Setup Script
# This script automates the setup process for the MentorX project

echo "=== MentorX Project Setup ==="
echo "Setting up development environment..."

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "Failed to create virtual environment. Please ensure Python 3.8+ is installed."
        exit 1
    fi
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "Failed to activate virtual environment."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Failed to install dependencies."
    exit 1
fi

# Download NLTK resources
echo "Downloading NLTK resources..."
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"
if [ $? -ne 0 ]; then
    echo "Failed to download NLTK resources."
    exit 1
fi

# Create necessary directories
echo "Creating necessary directories..."
mkdir -p uploads
mkdir -p src/vector_db

# Check if Ollama is installed
echo "Checking Ollama installation..."
if ! command -v ollama &> /dev/null; then
    echo "Ollama not found. Please install Ollama from https://ollama.ai/"
    echo "After installation, run: ollama pull mistral-7b"
else
    echo "Ollama found. Checking for Mistral-7B model..."
    # Check if Mistral-7B model is available
    if ! ollama list | grep -q "mistral-7b"; then
        echo "Mistral-7B model not found. Pulling model (this may take some time)..."
        ollama pull mistral-7b
    else
        echo "Mistral-7B model is already installed."
    fi
fi

echo "Setup complete! To run the application:"
echo "1. Ensure Ollama is running with: ollama serve"
echo "2. Start the application with: python app.py"
echo "3. Access the web interface at http://localhost:5000"
echo ""
echo "For more information, see the README.md and CONTRIBUTING.md files."
