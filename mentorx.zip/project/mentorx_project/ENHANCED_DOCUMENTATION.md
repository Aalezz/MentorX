# MentorX: Enhanced Personalized Learning Assistant

## Project Documentation

### Overview
MentorX is an advanced virtual learning assistant powered by Large Language Models (LLM) that provides personalized learning experiences for students, teachers, and parents. The platform features a comprehensive authentication system with role-based access, adaptive learning capabilities, and a modern, colorful user interface.

### Key Features

#### 1. Authentication and User Roles
- **User Registration**: Complete registration flow with role selection
- **Role-Based Access**: Tailored experiences for students, teachers, and parents
- **Session Management**: Secure authentication and session handling
- **Profile Management**: User profile customization and settings

#### 2. Adaptive Learning System
- **Learning Style Detection**: Identification of visual, auditory, reading/writing, or kinesthetic preferences
- **Performance Tracking**: Comprehensive monitoring of student progress across subjects
- **Content Recommendation**: Personalized learning paths based on performance and preferences
- **Difficulty Adjustment**: Dynamic content difficulty based on mastery level

#### 3. Role-Specific Dashboards
- **Student Dashboard**: Learning progress, recommended content, upcoming tasks, performance insights
- **Teacher Dashboard**: Class performance, student submissions, content library, student insights
- **Parent Dashboard**: Children overview, upcoming events, learning recommendations, teacher communications

#### 4. Content Management
- **Multi-format Support**: Upload and process various document formats
- **Content Extraction**: Intelligent parsing and structuring of educational materials
- **Content Adaptation**: Presentation adjustments based on learning style
- **Assessment Generation**: Creation of quizzes and tests with varying difficulty levels

### System Architecture

#### Frontend
- **Authentication Pages**: Login and registration with role selection
- **Role-Based Dashboards**: Tailored interfaces for each user type
- **Responsive Design**: Adapts to desktop, tablet, and mobile devices
- **Interactive Elements**: Dynamic components with real-time updates

#### Backend
- **User Management**: Authentication, authorization, and profile handling
- **Content Processing**: Document parsing, extraction, and structuring
- **Adaptive Engine**: Learning style detection and content adaptation
- **Performance Analytics**: Progress tracking and insight generation

#### Database Schema
- **Users Table**: Core user information and authentication details
- **Role-Specific Profiles**: Extended information for students, teachers, and parents
- **Content Repository**: Structured educational materials and metadata
- **Performance Metrics**: Tracking of user interactions and assessment results
- **Learning Paths**: Personalized sequences of learning materials

### Installation and Setup

#### Prerequisites
- Python 3.8+
- Flask
- NLTK
- python-docx
- PyPDF2
- Ollama with Mistral-7B model
- Modern web browser with JavaScript enabled

#### Setup Instructions
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Download NLTK resources:
   ```python
   import nltk
   nltk.download('punkt')
   nltk.download('stopwords')
   nltk.download('wordnet')
   ```
4. Ensure Ollama is running with Mistral-7B model
5. Run the application: `python app.py`
6. Access the web interface at `http://localhost:5000`

### User Guide

#### Student Experience
1. **Registration**: Sign up as a student, select grade level and subjects of interest
2. **Dashboard**: View personalized learning progress and recommendations
3. **Content Interaction**: Upload materials, generate questions, and get explanations
4. **Performance Tracking**: Monitor progress across subjects and topics

#### Teacher Experience
1. **Registration**: Sign up as a teacher, specify subjects taught and institution
2. **Dashboard**: Monitor class performance and student submissions
3. **Content Management**: Upload and share educational materials
4. **Student Insights**: Identify struggling students and learning style distributions

#### Parent Experience
1. **Registration**: Sign up as a parent, specify number of children and grade levels
2. **Dashboard**: Monitor children's progress and upcoming events
3. **Teacher Communication**: Message teachers and view communications
4. **Learning Support**: Access recommended resources for children

### Technical Implementation Details

#### Authentication System
- JWT-based authentication for secure session management
- Role-based access control with permission validation
- Password hashing with bcrypt for security
- Session timeout and refresh token handling

#### Adaptive Learning Engine
- Machine learning-based learning style detection
- Performance analysis using statistical models
- Content recommendation using similarity algorithms
- Difficulty adjustment based on performance thresholds

#### UI/UX Design
- Modern design with gradient accents and card-based layout
- Consistent color scheme across all pages
- Interactive elements with hover effects and animations
- Responsive design with mobile-first approach

### Future Enhancements
1. **Real-time Collaboration**: Enable student-teacher collaboration on documents
2. **AI-Powered Tutoring**: Implement conversational AI for direct tutoring
3. **Gamification Elements**: Add badges, points, and rewards for engagement
4. **Advanced Analytics**: Provide deeper insights into learning patterns
5. **Integration with LMS**: Connect with popular Learning Management Systems

### Troubleshooting
- **Authentication Issues**: Clear browser cookies and try again
- **Content Upload Problems**: Verify file format and size (max 20MB)
- **Performance Tracking Errors**: Ensure all assessments are properly completed
- **Display Issues**: Try different browsers or clear cache

### Support and Resources
- **Documentation**: Comprehensive guides available in the Help section
- **Community Forum**: Connect with other users for tips and assistance
- **Tutorial Videos**: Step-by-step guides for common tasks
- **Contact Support**: Email support@mentorx.edu for direct assistance
