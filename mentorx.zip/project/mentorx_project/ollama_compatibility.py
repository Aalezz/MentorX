#!/usr/bin/env python3

"""
MentorX Ollama 3.7 Compatibility Script
This script updates the MentorX project to ensure compatibility with Ollama 3.7
"""

import os
import sys
import json
import shutil
from pathlib import Path

def print_header(message):
    """Print a formatted header message"""
    print("\n" + "=" * 50)
    print(f" {message}")
    print("=" * 50)

def update_requirements():
    """Update requirements.txt with necessary dependencies for Ollama 3.7"""
    print_header("Updating Requirements")
    
    requirements_path = "requirements.txt"
    
    # Read current requirements
    with open(requirements_path, 'r') as file:
        current_requirements = file.read().splitlines()
    
    # Add new requirements if not already present
    new_requirements = [
        "flask",
        "python-docx",
        "PyPDF2",
        "nltk",
        "requests",
        "tqdm",  # Progress bar for downloads
        "colorama",  # Terminal colors
    ]
    
    updated_requirements = current_requirements.copy()
    added = []
    
    for req in new_requirements:
        # Check if requirement or a version of it already exists
        if not any(r.startswith(req) for r in current_requirements):
            updated_requirements.append(req)
            added.append(req)
    
    # Write updated requirements
    with open(requirements_path, 'w') as file:
        file.write('\n'.join(updated_requirements))
    
    if added:
        print(f"Added {len(added)} new requirements: {', '.join(added)}")
    else:
        print("No new requirements needed to be added.")
    
    return True

def create_docker_compose():
    """Create a docker-compose.yml file for easy deployment"""
    print_header("Creating Docker Compose Configuration")
    
    docker_compose_content = """version: '3'

services:
  mentorx:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - ./uploads:/app/uploads
      - ./src/vector_db:/app/src/vector_db
    environment:
      - FLASK_ENV=production
    depends_on:
      - ollama

  ollama:
    image: ollama/ollama:latest
    volumes:
      - ollama_data:/root/.ollama
    ports:
      - "11434:11434"
    command: serve

volumes:
  ollama_data:
"""
    
    with open("docker-compose.yml", 'w') as file:
        file.write(docker_compose_content)
    
    print("Created docker-compose.yml for easy deployment")
    return True

def create_dockerfile():
    """Create a Dockerfile for containerization"""
    print_header("Creating Dockerfile")
    
    dockerfile_content = """FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Download NLTK data
RUN python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"

# Copy application code
COPY . .

# Create necessary directories
RUN mkdir -p uploads src/vector_db

# Expose port
EXPOSE 5000

# Run the application
CMD ["python", "app.py"]
"""
    
    with open("Dockerfile", 'w') as file:
        file.write(dockerfile_content)
    
    print("Created Dockerfile for containerization")
    return True

def create_makefile():
    """Create a Makefile for common commands"""
    print_header("Creating Makefile")
    
    makefile_content = """# MentorX Makefile

.PHONY: setup run test clean docker-build docker-run

# Setup the project
setup:
	python setup_helper.py

# Run the application
run:
	python app.py

# Check Ollama status
check-ollama:
	python check_ollama.py

# Clean temporary files
clean:
	rm -rf __pycache__
	rm -rf src/__pycache__
	rm -rf src/*/__pycache__
	rm -rf uploads/*

# Docker commands
docker-build:
	docker-compose build

docker-run:
	docker-compose up

docker-stop:
	docker-compose down

# Pull Ollama Mistral-7B model
pull-model:
	ollama pull mistral-7b

# Help command
help:
	@echo "MentorX Makefile Commands:"
	@echo "  make setup        - Set up the project"
	@echo "  make run          - Run the application"
	@echo "  make check-ollama - Check Ollama status"
	@echo "  make clean        - Clean temporary files"
	@echo "  make docker-build - Build Docker containers"
	@echo "  make docker-run   - Run with Docker Compose"
	@echo "  make docker-stop  - Stop Docker containers"
	@echo "  make pull-model   - Pull Ollama Mistral-7B model"
"""
    
    with open("Makefile", 'w') as file:
        file.write(makefile_content)
    
    print("Created Makefile for common commands")
    return True

def update_readme():
    """Update README.md with improved instructions"""
    print_header("Updating README.md")
    
    readme_path = "README.md"
    
    # Read current README
    with open(readme_path, 'r') as file:
        current_readme = file.read()
    
    # Create new README content
    new_readme = """# MentorX Project

A personalized learning assistant powered by Large Language Models (LLM) that provides tailored educational experiences for students, teachers, and parents.

## Project Structure

```
mentorx_project/
├── src/
│   ├── content_ingestion/  # Content processing and extraction
│   ├── learning_system/    # LLM integration and question generation
│   ├── frontend/           # User interface components
│   └── utils/              # Shared utilities and helpers
├── frontend/               # Frontend templates and static files
├── app.py                  # Main application entry point
├── requirements.txt        # Python dependencies
├── setup.sh                # Bash setup script
├── setup_helper.py         # Python setup helper
├── check_ollama.py         # Ollama status checker
├── docker-compose.yml      # Docker Compose configuration
├── Dockerfile              # Docker configuration
└── Makefile                # Common commands
```

## Quick Start

### Option 1: Local Setup

1. **Run the setup helper:**
   ```bash
   python setup_helper.py
   ```

2. **Start Ollama:**
   ```bash
   ollama serve
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Access the web interface:**
   Open your browser and navigate to `http://localhost:5000`

### Option 2: Using Make Commands

1. **Setup the project:**
   ```bash
   make setup
   ```

2. **Check Ollama status:**
   ```bash
   make check-ollama
   ```

3. **Run the application:**
   ```bash
   make run
   ```

### Option 3: Using Docker

1. **Build and run with Docker Compose:**
   ```bash
   make docker-build
   make docker-run
   ```

2. **Access the web interface:**
   Open your browser and navigate to `http://localhost:5000`

## Environment Requirements

- Python 3.8+
- Ollama 3.7 with Mistral-7B model
- Modern web browser with JavaScript enabled

## Authentication

For demonstration purposes, the following accounts are available:

- **Student:** student@example.com / password123
- **Teacher:** teacher@example.com / password123
- **Parent:** parent@example.com / password123

## Documentation

For more detailed information, please refer to:

- [DOCUMENTATION.md](DOCUMENTATION.md) - Core functionality documentation
- [ENHANCED_DOCUMENTATION.md](ENHANCED_DOCUMENTATION.md) - Enhanced features documentation
- [CONTRIBUTING.md](CONTRIBUTING.md) - Contribution guidelines

## Ollama 3.7 Compatibility

This project is fully compatible with Ollama 3.7 and the Mistral-7B model. The setup scripts will help you configure everything correctly.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
"""
    
    # Write new README
    with open(readme_path, 'w') as file:
        file.write(new_readme)
    
    print("Updated README.md with improved instructions")
    return True

def create_env_example():
    """Create a .env.example file for environment variables"""
    print_header("Creating .env.example")
    
    env_content = """# MentorX Environment Variables

# Flask settings
FLASK_ENV=development
FLASK_DEBUG=1
SECRET_KEY=your_secret_key_here

# Ollama settings
OLLAMA_API_URL=http://localhost:11434/api
OLLAMA_MODEL=mistral-7b
OLLAMA_TIMEOUT=60

# Database settings (if needed in the future)
# DB_USERNAME=root
# DB_PASSWORD=password
# DB_HOST=localhost
# DB_PORT=3306
# DB_NAME=mentorx
"""
    
    with open(".env.example", 'w') as file:
        file.write(env_content)
    
    print("Created .env.example file")
    return True

def create_run_script():
    """Create a simple run script for Windows users"""
    print_header("Creating Run Script")
    
    # Create Windows batch file
    windows_script = """@echo off
echo Starting MentorX application...

REM Check if Python is installed
where python >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Python is not installed or not in PATH.
    echo Please install Python 3.8 or higher.
    pause
    exit /b 1
)

REM Check if virtual environment exists
if not exist venv (
    echo Virtual environment not found.
    echo Please run setup_helper.py first.
    pause
    exit /b 1
)

REM Activate virtual environment and run app
call venv\Scripts\activate
python app.py

pause
"""
    
    with open("run.bat", 'w') as file:
        file.write(windows_script)
    
    # Create shell script for Unix
    unix_script = """#!/bin/bash

echo "Starting MentorX application..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python is not installed or not in PATH."
    echo "Please install Python 3.8 or higher."
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Virtual environment not found."
    echo "Please run setup_helper.py first."
    exit 1
fi

# Activate virtual environment and run app
source venv/bin/activate
python app.py
"""
    
    with open("run.sh", 'w') as file:
        file.write(unix_script)
    
    # Make the Unix script executable
    os.chmod("run.sh", 0o755)
    
    print("Created run scripts for Windows (run.bat) and Unix (run.sh)")
    return True

def main():
    """Main function to update the project for Ollama 3.7 compatibility"""
    print_header("MentorX Ollama 3.7 Compatibility Update")
    
    # Change to the project directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Run all update steps
    update_requirements()
    create_docker_compose()
    create_dockerfile()
    create_makefile()
    update_readme()
    create_env_example()
    create_run_script()
    
    print_header("Update Complete")
    print("The MentorX project has been updated for Ollama 3.7 compatibility.")
    print("New files created:")
    print("- docker-compose.yml - For containerized deployment")
    print("- Dockerfile - For building Docker image")
    print("- Makefile - For common commands")
    print("- .env.example - Template for environment variables")
    print("- run.bat/run.sh - Simple run scripts")
    print("\nThe README.md has been updated with improved instructions.")
    print("\nTo start the application:")
    print("1. Ensure Ollama is running with: ollama serve")
    print("2. Run the application with: python app.py")
    print("   Or use: make run")
    print("\nFor Docker deployment:")
    print("1. Build and run with: make docker-build && make docker-run")

if __name__ == "__main__":
    main()
